from __future__ import unicode_literals

from django.apps import AppConfig


class LoginRegAppConfig(AppConfig):
    name = 'login_reg_app'
